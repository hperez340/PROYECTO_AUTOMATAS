from gui import SimuladorGUI


if __name__ == "__main__":
    app = SimuladorGUI()
    app.mainloop()
